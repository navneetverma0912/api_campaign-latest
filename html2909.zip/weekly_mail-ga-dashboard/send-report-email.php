<?php
/**
 * send-report-email.php
 * ---------------------------------------------------------------------
 * Pulls the GA4 report data, renders it into the dashboard-style email
 * template, and sends it via SMTP using PHPMailer.
 *
 * Run manually to test:
 *   php send-report-email.php
 *
 * Override the date range for a one-off run:
 *   php send-report-email.php --start=2026-06-22 --end=2026-07-05
 *
 * Typical cron (every other Monday at 8am):
 *   0 8 * * 1 /usr/bin/php /path/to/send-report-email.php >> /path/to/ga4-email.log 2>&1
 *   (see README for how to make cron skip alternate weeks)
 * ---------------------------------------------------------------------
 */

require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/ga4-report-lib.php';
require_once __DIR__ . '/email-template.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception as PHPMailerException;

/*
|--------------------------------------------------------------------------
| Load config
|--------------------------------------------------------------------------
*/

$configPath = __DIR__ . '/config.php';

if (!file_exists($configPath)) {
    fwrite(STDERR, "Missing config.php. Copy config.example.php to config.php and fill in your values.\n");
    exit(1);
}

$config = require $configPath;

/*
|--------------------------------------------------------------------------
| Optional CLI overrides for the date range, e.g.:
|   php send-report-email.php --start=2026-06-22 --end=2026-07-05
|--------------------------------------------------------------------------
*/

$startDate = $config['report_window']['start_date'] ?? '14daysAgo';
$endDate   = $config['report_window']['end_date'] ?? 'yesterday';

if (PHP_SAPI === 'cli') {
    $opts = getopt('', ['start:', 'end:']);
    if (!empty($opts['start'])) {
        $startDate = $opts['start'];
    }
    if (!empty($opts['end'])) {
        $endDate = $opts['end'];
    }
}

/*
|--------------------------------------------------------------------------
| 1. Fetch the GA4 report data
|--------------------------------------------------------------------------
*/

try {
    $report = ga4_build_report(
        $config['ga']['property_id'],
        $startDate,
        $endDate,
        $config['ga']['credentials_path']
    );
} catch (Throwable $e) {
    fwrite(STDERR, 'GA4 fetch failed: ' . $e->getMessage() . "\n");
    ga4_send_failure_alert($config, 'GA4 fetch failed', $e->getMessage());
    exit(1);
}

/*
|--------------------------------------------------------------------------
| 2. Render the email HTML
|--------------------------------------------------------------------------
*/

$logoCid = null;
$logoPath = $config['report']['logo_path'] ?? '';
$logoSrc = '';

if ($logoPath && file_exists($logoPath)) {
    $logoCid = 'ga4reportlogo';
    $logoSrc = 'cid:' . $logoCid;
}

$html = render_ga4_email_html($report, [
    'brand_name'    => $config['report']['brand_name'] ?? 'Website Analytics',
    'report_title'  => $config['report']['report_title'] ?? 'Website Analytics (GA4) Report',
    'dashboard_url' => $config['report']['dashboard_url'] ?? '#',
    'footer_note'   => $config['report']['footer_note'] ?? '',
    'accent_color'  => $config['report']['accent_color'] ?? '#F0640A',
    'logo_src'      => $logoSrc,
]);

/*
|--------------------------------------------------------------------------
| 3. Send via SMTP (PHPMailer)
|--------------------------------------------------------------------------
*/

$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host       = $config['smtp']['host'];
    $mail->Port       = $config['smtp']['port'];
    $mail->SMTPAuth   = true;
    $mail->Username   = $config['smtp']['username'];
    $mail->Password   = $config['smtp']['password'];
    $mail->SMTPSecure = $config['smtp']['encryption'] === 'ssl'
        ? PHPMailer::ENCRYPTION_SMTPS
        : PHPMailer::ENCRYPTION_STARTTLS;

    $mail->setFrom($config['smtp']['from_email'], $config['smtp']['from_name'] ?? '');

    foreach ($config['recipients'] as $recipient) {
        $mail->addAddress($recipient);
    }

    foreach ($config['bcc'] ?? [] as $bccAddress) {
        $mail->addBCC($bccAddress);
    }

    if ($logoCid) {
        $mail->addEmbeddedImage($logoPath, $logoCid);
    }

    $mail->isHTML(true);
    $mail->CharSet = 'UTF-8';
    $mail->Subject = sprintf(
        '%s — Site Performance (%s to %s)',
        $config['report']['brand_name'] ?? 'Website Analytics',
        $report['start'],
        $report['end']
    );
    $mail->Body    = $html;
    $mail->AltBody = ga4_plain_text_summary($report);

    $mail->send();

    echo "Report email sent successfully to " . implode(', ', $config['recipients']) . "\n";

} catch (PHPMailerException $e) {
    $error = $mail->ErrorInfo;
    fwrite(STDERR, 'Email send failed: ' . $error . "\n");
    ga4_send_failure_alert($config, 'Email send failed', $error);
    exit(1);
}

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

/**
 * Plain-text fallback for clients that don't render HTML email.
 */
function ga4_plain_text_summary(array $report): string
{
    $lines = [];
    $lines[] = ($report['name'] ?? 'GA4 Report');
    $lines[] = str_repeat('-', 40);

    foreach ($report['kpis'] ?? [] as $kpi) {
        $lines[] = sprintf('%-28s %s', $kpi['label'], $kpi['value']);
    }

    $lines[] = '';
    $lines[] = 'Open the interactive dashboard for full detail.';

    return implode("\n", $lines);
}

/**
 * Best-effort plain-text failure alert, sent with a fresh PHPMailer
 * instance so it doesn't depend on any state from the failed attempt.
 */
function ga4_send_failure_alert(array $config, string $subject, string $message): void
{
    if (empty($config['alert_email'])) {
        return;
    }

    try {
        $alertMailer = new PHPMailer(true);
        $alertMailer->isSMTP();
        $alertMailer->Host       = $config['smtp']['host'];
        $alertMailer->Port       = $config['smtp']['port'];
        $alertMailer->SMTPAuth   = true;
        $alertMailer->Username   = $config['smtp']['username'];
        $alertMailer->Password   = $config['smtp']['password'];
        $alertMailer->SMTPSecure = $config['smtp']['encryption'] === 'ssl'
            ? PHPMailer::ENCRYPTION_SMTPS
            : PHPMailer::ENCRYPTION_STARTTLS;

        $alertMailer->setFrom($config['smtp']['from_email'], $config['smtp']['from_name'] ?? '');
        $alertMailer->addAddress($config['alert_email']);
        $alertMailer->Subject = 'GA4 report email job failed: ' . $subject;
        $alertMailer->Body    = $message;
        $alertMailer->send();
    } catch (Throwable $e) {
        // Swallow - we're already in an error path and logging to STDERR
        // in the caller is the best we can do.
    }
}
