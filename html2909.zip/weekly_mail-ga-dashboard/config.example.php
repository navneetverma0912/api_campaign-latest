<?php
/**
 * config.example.php
 * ---------------------------------------------------------------------
 * Copy this file to config.php and fill in your real values.
 * Do NOT commit config.php to version control - it holds credentials.
 * ---------------------------------------------------------------------
 */

return [

    // ---- Google Analytics 4 ------------------------------------------------
    'ga' => [
        'property_id'      => '524099388', // Trivium (from your original file)
        'credentials_path' => __DIR__ . '/credentials-ga.json',
    ],

    // ---- Report window ------------------------------------------------------
    // Accepts absolute dates ('2026-06-22') or GA4 relative dates
    // ('14daysAgo', 'yesterday', 'today'). Left as relative dates here so the
    // same config keeps working every time the cron job runs.
    'report_window' => [
        'start_date' => '14daysAgo',
        'end_date'   => 'yesterday', // GA4 same-day data is often incomplete
    ],

    // ---- SMTP -----------------------------------------------------------
    'smtp' => [
        'host'       => 'smtp.gmail.com',       // e.g. smtp.gmail.com, smtp.office365.com, your host's SMTP
        'port'       => 587,                    // 587 = STARTTLS, 465 = SSL
        'encryption' => 'tls',                  // 'tls' or 'ssl'
        'username'   => 'you@example.com',
        'password'   => 'your-app-password',    // Gmail/Google Workspace: use an App Password, not your login password
        'from_email' => 'analytics@example.com',
        'from_name'  => 'Trivium CTE Analytics',
    ],

    // ---- Recipients -------------------------------------------------------
    'recipients' => [
        'owner@example.com',
        // 'someone-else@example.com',
    ],

    // Optional: send a copy to yourself so you know the job ran even when
    // recipients don't reply.
    'bcc' => [
        // 'me@example.com',
    ],

    // ---- Branding / content -------------------------------------------------
    'report' => [
        'brand_name'    => 'Trivium CTE',
        'report_title'  => 'Website Analytics (GA4) · Detailed Fortnightly Report',
        'dashboard_url' => 'https://your-dashboard-url.example',
        'footer_note'   => 'An initiative of Trivium Inc and Feast Software',
        'accent_color'  => '#F0640A',
        // Path to a logo image to embed inline in the email (PNG/JPG).
        // Leave empty to omit the logo block entirely.
        'logo_path'     => __DIR__ . '/logo.png',
    ],

    // ---- On-failure alert ---------------------------------------------------
    // If the GA4 fetch or the send itself fails, also email this address
    // a short plain-text error so failures don't go unnoticed.
    'alert_email' => 'you@example.com',
];
