<?php
/**
 * email-template.php
 * ---------------------------------------------------------------------
 * Renders the "Website Analytics — Detailed Fortnightly Report" email
 * from a $report array (the exact structure ga4_build_report() returns,
 * same as your existing GA4-dashboard-api.php JSON output).
 *
 * Usage:
 *   $html = render_ga4_email_html($report, [
 *       'brand_name'    => 'Trivium CTE',
 *       'report_title'  => 'Website Analytics (GA4) · Detailed Fortnightly Report',
 *       'dashboard_url' => 'https://your-dashboard-url.example',
 *       'logo_src'      => 'cid:logo',   // or a data:image/... URI
 *   ]);
 * ---------------------------------------------------------------------
 */

function h($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function ga4_number(int $n): string
{
    return number_format($n);
}

/**
 * Renders one KPI's change cell: ▲ x% in green, ▼ x% in red, or a plain
 * dash when there is no delta to show (e.g. delta is 0 or not supplied).
 */
function ga4_render_delta($delta): string
{
    $delta = (float) $delta;

    if ($delta > 0) {
        return '<span style="color:#1F9D55;font-weight:700;">&#9650; ' . h(abs($delta)) . '%</span>';
    }

    if ($delta < 0) {
        return '<span style="color:#E24B4B;font-weight:700;">&#9660; ' . h(abs($delta)) . '%</span>';
    }

    return '<span style="color:#9CA0B3;font-weight:700;">—</span>';
}

/**
 * Format a report 'start'/'end' value (either 'YYYY-MM-DD' or a GA4
 * relative date like '14daysAgo'/'today') into a readable label.
 * Falls back to the raw string if it can't be parsed.
 */
function ga4_format_report_date(string $value): string
{
    $ts = strtotime($value);
    if ($ts === false) {
        return h($value);
    }
    return h(date('d M Y', $ts));
}

function render_ga4_email_html(array $report, array $options = []): string
{
    $brandName    = $options['brand_name']    ?? 'Trivium CTE';
    $reportTitle  = $options['report_title']  ?? 'Website Analytics (GA4) · Detailed Fortnightly Report';
    $dashboardUrl = $options['dashboard_url'] ?? '#';
    $logoSrc      = $options['logo_src']      ?? '';
    $footerNote   = $options['footer_note']   ?? 'An initiative of Trivium Inc and Feast Software';
    $accent       = $options['accent_color']  ?? '#F0640A';

    $startLabel = ga4_format_report_date((string) ($report['start'] ?? ''));
    $endLabel   = ga4_format_report_date((string) ($report['end'] ?? ''));

    ob_start();
    ?>
<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title><?= h($reportTitle) ?></title>
<!--[if mso]>
<noscript><xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch></o:OfficeDocumentSettings></xml></noscript>
<![endif]-->
<style>
  body, table, td { font-family: 'Poppins', 'Segoe UI', Arial, sans-serif; }
  body { margin:0; padding:0; background-color:#F4F4F2; -webkit-text-size-adjust:100%; }
  img { border:0; line-height:100%; outline:none; text-decoration:none; }
  table { border-collapse:collapse !important; }
  a { text-decoration:none; }
  .kpi-num { font-family:'Poppins','Segoe UI',Arial,sans-serif; font-weight:800; font-size:18px; color:#0B0B0C; }
  .kpi-lbl { font-family:Arial,sans-serif; font-size:9.5px; font-weight:700; color:#6B7085; text-transform:uppercase; letter-spacing:.03em; }
  .kpi-delta { font-family:Arial,sans-serif; font-size:10px; font-weight:700; }
  .kpi-desc { font-family:Arial,sans-serif; font-size:9.5px; color:#9CA0B3; margin-top:2px; }
  .sec-title { font-family:'Poppins','Segoe UI',Arial,sans-serif; font-size:15px; font-weight:700; color:#0B0B0C; margin:0 0 4px; }
  .sec-sub { font-family:Arial,sans-serif; font-size:11.5px; color:#6B7085; margin:0 0 14px; }
  .th { font-family:Arial,sans-serif; font-size:10px; font-weight:700; color:#6B7085; text-transform:uppercase; letter-spacing:.03em; padding:9px 10px; background-color:#F7F7F5; }
  .td { font-family:Arial,sans-serif; font-size:11.5px; color:#2B2740; padding:9px 10px; border-bottom:1px solid #EFEDEB; }
  .bar-lbl { font-family:Arial,sans-serif; font-size:11px; color:#2B2740; padding:6px 0 2px; }
  @media only screen and (max-width:600px){
    .container{ width:100% !important; }
    .kpi-cell{ display:inline-block !important; width:31% !important; padding-bottom:14px !important; }
    .px{ padding-left:18px !important; padding-right:18px !important; }
  }
</style>
</head>
<body style="margin:0;padding:0;background-color:#F4F4F2;">
<div style="display:none;max-height:0;overflow:hidden;opacity:0;">
  Full detail: <?= ga4_number((int) ($report['totalVisits'] ?? 0)) ?> visits, daily trend, device &amp; country split, acquisition, all page views, behavior signals, clicks &amp; video — everything inside.
</div>

<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#F4F4F2;">
<tr><td align="center" style="padding:32px 16px;">

  <table role="presentation" class="container" width="640" cellpadding="0" cellspacing="0" style="width:640px;max-width:640px;background-color:#FFFFFF;border-radius:16px;overflow:hidden;">

    <!-- HEADER -->
    <tr>
      <td style="background-color:#0B0B0C;padding:30px 36px;" class="px">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
          <tr>
            <?php if ($logoSrc): ?>
            <td style="background-color:#FFFFFF;border-radius:10px;padding:8px 14px;" width="1">
              <img src="<?= h($logoSrc) ?>" width="120" alt="<?= h($brandName) ?>" style="display:block;">
            </td>
            <?php endif; ?>
            <td></td>
          </tr>
        </table>
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin-top:18px;">
          <tr>
            <td>
              <p style="margin:0 0 6px;font-family:'Poppins','Segoe UI',Arial,sans-serif;font-size:10px;font-weight:700;letter-spacing:.16em;text-transform:uppercase;color:#B7C48A;"><?= h($reportTitle) ?></p>
              <p style="margin:0;font-family:'Poppins','Segoe UI',Arial,sans-serif;font-size:23px;font-weight:800;color:#FFFFFF;"><?= h($brandName) ?> — Site Performance</p>
              <p style="margin:8px 0 0;font-family:Arial,sans-serif;font-size:12.5px;color:#B5B3B2;"><?= $startLabel ?> &rarr; <?= $endLabel ?> &nbsp;&middot;&nbsp; Data source: Google Analytics</p>
            </td>
          </tr>
        </table>
      </td>
    </tr>

    <!-- KPI ROW -->
    <tr>
      <td class="px" style="padding:28px 36px 8px;">
        <p class="sec-title">Key numbers at a glance</p>
        <p class="sec-sub">vs. the previous period</p>
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #EDEDEB;border-radius:10px;overflow:hidden;">
          <tr><td class="th">Metric</td><td class="th" align="right">Value</td><td class="th" align="right">Change</td></tr>
          <?php $kpis = $report['kpis'] ?? []; foreach ($kpis as $i => $kpi):
              $isLast = ($i === count($kpis) - 1);
              $borderStyle = $isLast ? 'border-bottom:none;' : '';
          ?>
          <tr>
            <td class="td" style="<?= $borderStyle ?>"><?= h($kpi['label']) ?> <?php if (!empty($kpi['desc'])): ?><span style="color:#9CA0B3;">— <?= h($kpi['desc']) ?></span><?php endif; ?></td>
            <td class="td" align="right" style="<?= $borderStyle ?>font-family:'Poppins',Arial,sans-serif;font-weight:800;"><?= h($kpi['value']) ?></td>
            <td class="td" align="right" style="<?= $borderStyle ?>"><?= ga4_render_delta($kpi['delta'] ?? 0) ?></td>
          </tr>
          <?php endforeach; ?>
        </table>
      </td>
    </tr>

    <tr><td class="px" style="padding:16px 36px 0;"><table width="100%" cellpadding="0" cellspacing="0"><tr><td style="border-top:1px solid #EDEDEB;font-size:0;line-height:0;">&nbsp;</td></tr></table></td></tr>

    <!-- DAILY TRAFFIC -->
    <?php $daily = $report['daily'] ?? []; if (!empty($daily)):
        $maxTotal = max(array_column($daily, 'total'));
        $maxTotal = $maxTotal > 0 ? $maxTotal : 1;
        $bestLabel = $report['bestDay']['label'] ?? null;
        $quietLabel = $report['quietestDay']['label'] ?? null;
    ?>
    <tr>
      <td class="px" style="padding:24px 36px 4px;">
        <p class="sec-title">How traffic changed day by day</p>
        <p class="sec-sub">Total visits, each day (bar = share of the busiest day)</p>
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
          <?php foreach ($daily as $day):
              $width = max(3, round(($day['total'] / $maxTotal) * 100));
              $isBest = ($bestLabel !== null && $day['label'] === $bestLabel);
              $isQuiet = (!$isBest && $quietLabel !== null && $day['label'] === $quietLabel);
              $barColor = $isBest ? '#0E8FB5' : ($isQuiet ? '#E24B4B' : $accent);
              $tag = $isBest ? ' — best day' : ($isQuiet ? ' — quietest' : '');
          ?>
          <tr><td class="bar-lbl"><?= h($day['label']) ?> <span style="float:right;font-weight:700;"><?= ga4_number($day['total']) ?><?= h($tag) ?></span></td></tr>
          <tr><td>
            <table width="100%" cellpadding="0" cellspacing="0"><tr>
              <td width="<?= (int) $width ?>%" bgcolor="<?= h($barColor) ?>" style="font-size:0;line-height:7px;">&nbsp;</td>
              <?php if ($width < 100): ?><td bgcolor="#EDEDEB" style="font-size:0;line-height:7px;">&nbsp;</td><?php endif; ?>
            </tr></table>
          </td></tr>
          <?php endforeach; ?>
        </table>

        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin-top:16px;">
          <tr>
            <td width="33%" style="background-color:#F2F6E8;border-radius:8px 0 0 8px;padding:14px 12px;">
              <div style="font-family:Arial,sans-serif;font-size:9.5px;font-weight:700;color:#6B7085;text-transform:uppercase;">Best Day</div>
              <div style="font-family:'Poppins',Arial,sans-serif;font-weight:700;font-size:13px;color:#0B0B0C;margin-top:4px;"><?= h($report['bestDay']['label'] ?? '—') ?></div>
              <div style="font-family:Arial,sans-serif;font-size:11px;color:#6B7085;"><?= ga4_number($report['bestDay']['value'] ?? 0) ?> visits</div>
            </td>
            <td width="33%" style="background-color:#F7F7F5;padding:14px 12px;">
              <div style="font-family:Arial,sans-serif;font-size:9.5px;font-weight:700;color:#6B7085;text-transform:uppercase;">Quietest Day</div>
              <div style="font-family:'Poppins',Arial,sans-serif;font-weight:700;font-size:13px;color:#0B0B0C;margin-top:4px;"><?= h($report['quietestDay']['label'] ?? '—') ?></div>
              <div style="font-family:Arial,sans-serif;font-size:11px;color:#6B7085;"><?= ga4_number($report['quietestDay']['value'] ?? 0) ?> visit<?= ($report['quietestDay']['value'] ?? 0) == 1 ? '' : 's' ?></div>
            </td>
            <td width="33%" style="background-color:#E7F6FA;border-radius:0 8px 8px 0;padding:14px 12px;">
              <div style="font-family:Arial,sans-serif;font-size:9.5px;font-weight:700;color:#6B7085;text-transform:uppercase;">Total Visits</div>
              <div style="font-family:'Poppins',Arial,sans-serif;font-weight:700;font-size:13px;color:#0B0B0C;margin-top:4px;"><?= ga4_number((int) ($report['totalVisits'] ?? 0)) ?></div>
              <div style="font-family:Arial,sans-serif;font-size:11px;color:#6B7085;">over the period</div>
            </td>
          </tr>
        </table>
      </td>
    </tr>
    <?php endif; ?>

    <tr><td class="px" style="padding:20px 36px 0;"><table width="100%" cellpadding="0" cellspacing="0"><tr><td style="border-top:1px solid #EDEDEB;font-size:0;line-height:0;">&nbsp;</td></tr></table></td></tr>

    <!-- DEVICE + COUNTRY -->
    <tr>
      <td class="px" style="padding:24px 36px 4px;">
        <p class="sec-title">Visitor demographics</p>
        <p class="sec-sub">Device used &amp; where visitors are from</p>

        <?php $devices = $report['device'] ?? []; $deviceTotal = array_sum(array_column($devices, 'value')); $deviceTotal = $deviceTotal > 0 ? $deviceTotal : 1; ?>
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #EDEDEB;border-radius:10px;overflow:hidden;margin-bottom:16px;">
          <tr><td class="th">Device</td><td class="th" align="right">Visitors</td><td class="th" align="right">Share</td></tr>
          <?php foreach ($devices as $i => $d): $isLast = ($i === count($devices) - 1); $border = $isLast ? 'border-bottom:none;' : ''; ?>
          <tr>
            <td class="td" style="<?= $border ?>"><?= h($d['label']) ?></td>
            <td class="td" align="right" style="<?= $border ?>font-weight:700;"><?= ga4_number($d['value']) ?></td>
            <td class="td" align="right" style="<?= $border ?>"><?= h(round(($d['value'] / $deviceTotal) * 100, 1)) ?>%</td>
          </tr>
          <?php endforeach; ?>
        </table>

        <?php
          $countries = $report['countries'] ?? [];
          usort($countries, fn($a, $b) => $b['value'] <=> $a['value']);
          $topCountries = array_slice($countries, 0, 10);
        ?>
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #EDEDEB;border-radius:10px;overflow:hidden;">
          <tr><td class="th">#</td><td class="th">Country</td><td class="th" align="right">Visitors</td></tr>
          <?php foreach ($topCountries as $i => $c): $isLast = ($i === count($topCountries) - 1); $border = $isLast ? 'border-bottom:none;' : ''; ?>
          <tr>
            <td class="td" style="<?= $border ?>"><?= $i + 1 ?></td>
            <td class="td" style="<?= $border ?>"><?= h($c['label']) ?></td>
            <td class="td" align="right" style="<?= $border ?>font-weight:700;"><?= ga4_number($c['value']) ?></td>
          </tr>
          <?php endforeach; ?>
        </table>
      </td>
    </tr>

    <tr><td class="px" style="padding:20px 36px 0;"><table width="100%" cellpadding="0" cellspacing="0"><tr><td style="border-top:1px solid #EDEDEB;font-size:0;line-height:0;">&nbsp;</td></tr></table></td></tr>

    <!-- ACQUISITION -->
    <?php $acquisition = $report['acquisition'] ?? []; ?>
    <tr>
      <td class="px" style="padding:24px 36px 4px;">
        <p class="sec-title">How did people find the site?</p>
        <p class="sec-sub"><?= ga4_number((int) ($report['totalVisits'] ?? 0)) ?> total visits, by source</p>
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #EDEDEB;border-radius:10px;overflow:hidden;">
          <tr><td class="th">Channel</td><td class="th" align="right">Visits</td><td class="th" align="right">Share</td></tr>
          <?php foreach ($acquisition as $i => $a): $isLast = ($i === count($acquisition) - 1); $border = $isLast ? 'border-bottom:none;' : ''; ?>
          <tr>
            <td class="td" style="<?= $border ?>"><strong><?= h($a['label']) ?></strong><br><span style="color:#9CA0B3;font-size:10.5px;"><?= h($a['desc']) ?></span></td>
            <td class="td" align="right" style="<?= $border ?>font-weight:700;"><?= ga4_number($a['visits']) ?></td>
            <td class="td" align="right" style="<?= $border ?>"><?= h($a['pct']) ?>%</td>
          </tr>
          <?php endforeach; ?>
        </table>
      </td>
    </tr>

    <tr><td class="px" style="padding:20px 36px 0;"><table width="100%" cellpadding="0" cellspacing="0"><tr><td style="border-top:1px solid #EDEDEB;font-size:0;line-height:0;">&nbsp;</td></tr></table></td></tr>

    <!-- FULL PAGE VIEWS -->
    <?php
      $pageViews = $report['pageViews'] ?? [];
      usort($pageViews, fn($a, $b) => $b['views'] <=> $a['views']);
      $pageViewCap = 40;
      $shownPageViews = array_slice($pageViews, 0, $pageViewCap);
    ?>
    <tr>
      <td class="px" style="padding:24px 36px 4px;">
        <p class="sec-title">Page views — every page</p>
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #EDEDEB;border-radius:10px;overflow:hidden;">
          <tr><td class="th">Page</td><td class="th" align="right">Views</td></tr>
          <?php foreach ($shownPageViews as $i => $p): $isLast = ($i === count($shownPageViews) - 1); $border = $isLast ? 'border-bottom:none;' : ''; ?>
          <tr>
            <td class="td" style="<?= $border ?>"><?= h($p['name']) ?></td>
            <td class="td" align="right" style="<?= $border ?>font-weight:700;"><?= ga4_number($p['views']) ?></td>
          </tr>
          <?php endforeach; ?>
        </table>
        <?php if (count($pageViews) > $pageViewCap): ?>
        <p style="margin:8px 0 0;font-family:Arial,sans-serif;font-size:10.5px;color:#9CA0B3;">+ <?= count($pageViews) - $pageViewCap ?> more pages not shown here — see the full dashboard.</p>
        <?php endif; ?>
      </td>
    </tr>

    <!-- TOP LANDING PAGES -->
    <?php
      $topPages = $report['topPages'] ?? [];
      usort($topPages, fn($a, $b) => $b['sessions'] <=> $a['sessions']);
      $topLanding = array_slice($topPages, 0, 5);
    ?>
    <tr>
      <td class="px" style="padding:20px 36px 4px;">
        <p class="sec-title">Where visitors first landed — top 5</p>
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #EDEDEB;border-radius:10px;overflow:hidden;">
          <tr><td class="th">Page</td><td class="th" align="right">Sessions</td><td class="th" align="right">Share</td><td class="th" align="right">Bounce</td></tr>
          <?php foreach ($topLanding as $i => $p): $isLast = ($i === count($topLanding) - 1); $border = $isLast ? 'border-bottom:none;' : ''; ?>
          <tr>
            <td class="td" style="<?= $border ?>"><?= h($p['name']) ?></td>
            <td class="td" align="right" style="<?= $border ?>"><?= ga4_number($p['sessions']) ?></td>
            <td class="td" align="right" style="<?= $border ?>font-weight:700;"><?= h($p['share']) ?>%</td>
            <td class="td" align="right" style="<?= $border ?>"><?= h($p['bounce']) ?>%</td>
          </tr>
          <?php endforeach; ?>
        </table>
      </td>
    </tr>

    <tr><td class="px" style="padding:20px 36px 0;"><table width="100%" cellpadding="0" cellspacing="0"><tr><td style="border-top:1px solid #EDEDEB;font-size:0;line-height:0;">&nbsp;</td></tr></table></td></tr>

    <!-- HIGHLIGHTS + BEHAVIOR -->
    <?php $highlights = $report['highlights'] ?? []; ?>
    <tr>
      <td class="px" style="padding:24px 36px 4px;">
        <p class="sec-title">Visitor behavior — key highlights</p>
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
          <tr>
            <?php foreach ($highlights as $hl): ?>
            <td class="kpi-cell" width="<?= (int) (100 / max(1, count($highlights))) ?>%" align="center" style="padding:8px 4px;">
              <div class="kpi-num" style="font-size:16px;"><?= ga4_number((int) $hl['value']) ?></div>
              <div class="kpi-lbl"><?= h($hl['label']) ?></div>
              <div class="kpi-desc"><?= h($hl['note']) ?></div>
            </td>
            <?php endforeach; ?>
          </tr>
        </table>

        <?php $behavior = $report['behavior'] ?? []; usort($behavior, fn($a, $b) => $b['value'] <=> $a['value']); ?>
        <p class="sec-sub" style="margin-top:18px;margin-bottom:8px;">All action signals recorded</p>
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #EDEDEB;border-radius:10px;overflow:hidden;">
          <tr><td class="th">Action</td><td class="th" align="right">Count</td></tr>
          <?php foreach ($behavior as $i => $b): $isLast = ($i === count($behavior) - 1); $border = $isLast ? 'border-bottom:none;' : ''; ?>
          <tr>
            <td class="td" style="<?= $border ?>"><?= h($b['label']) ?></td>
            <td class="td" align="right" style="<?= $border ?>font-weight:700;"><?= ga4_number((int) $b['value']) ?></td>
          </tr>
          <?php endforeach; ?>
        </table>
      </td>
    </tr>

    <tr><td class="px" style="padding:20px 36px 0;"><table width="100%" cellpadding="0" cellspacing="0"><tr><td style="border-top:1px solid #EDEDEB;font-size:0;line-height:0;">&nbsp;</td></tr></table></td></tr>

    <!-- CLICKS & VIDEO -->
    <?php $topClicks = $report['topClicks'] ?? []; ?>
    <tr>
      <td class="px" style="padding:24px 36px 4px;">
        <p class="sec-title">What did they click?</p>
        <?php if (empty($topClicks)): ?>
        <p class="sec-sub">No tagged click events (contact-sales button, outbound links, downloads) were recorded for this period.</p>
        <?php else: ?>
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #EDEDEB;border-radius:10px;overflow:hidden;margin-bottom:16px;">
          <?php foreach ($topClicks as $i => $c): $isLast = ($i === count($topClicks) - 1); $border = $isLast ? '' : 'border-bottom:1px solid #EDEDEB;'; ?>
          <tr>
            <td style="padding:14px 16px;<?= $border ?>">
              <table width="100%" cellpadding="0" cellspacing="0"><tr>
                <td width="34" valign="top"><div style="width:30px;height:30px;background-color:#FDEEE0;color:<?= h($accent) ?>;border-radius:8px;text-align:center;line-height:30px;font-family:'Poppins',Arial,sans-serif;font-weight:800;font-size:13px;"><?= ga4_number($c['count']) ?></div></td>
                <td style="padding-left:12px;">
                  <p style="margin:0;font-family:'Poppins',Arial,sans-serif;font-weight:700;font-size:12.5px;color:#0B0B0C;"><?= h($c['label']) ?></p>
                  <p style="margin:2px 0 0;font-family:Arial,sans-serif;font-size:10.5px;color:#9CA0B3;"><?= h($c['note']) ?></p>
                </td>
              </tr></table>
            </td>
          </tr>
          <?php endforeach; ?>
        </table>
        <?php endif; ?>

        <?php $video = $report['video'] ?? ['totalEvents' => 0, 'stages' => []]; $stages = $video['stages'] ?? []; ?>
        <p class="sec-title">What did they watch?</p>
        <p class="sec-sub"><?= ga4_number((int) ($video['totalEvents'] ?? 0)) ?> video events tracked</p>
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #EDEDEB;border-radius:10px;overflow:hidden;">
          <tr><td class="th">Stage</td><td class="th" align="right">Viewers</td></tr>
          <?php foreach ($stages as $i => $s): $isLast = ($i === count($stages) - 1); $border = $isLast ? 'border-bottom:none;' : ''; ?>
          <tr>
            <td class="td" style="<?= $border ?>"><?= h($s['label']) ?> <span style="color:#9CA0B3;">— <?= h($s['note']) ?></span></td>
            <td class="td" align="right" style="<?= $border ?>font-weight:700;"><?= ga4_number((int) $s['viewers']) ?></td>
          </tr>
          <?php endforeach; ?>
        </table>
      </td>
    </tr>

    <!-- CTA -->
    <tr>
      <td align="center" class="px" style="padding:30px 36px 8px;">
        <table role="presentation" cellpadding="0" cellspacing="0">
          <tr>
            <td align="center" style="background-color:#6E9A1B;background:linear-gradient(90deg,#6E9A1B,#0E8FB5);border-radius:100px;">
              <a href="<?= h($dashboardUrl) ?>" style="display:inline-block;padding:13px 32px;font-family:'Poppins','Segoe UI',Arial,sans-serif;font-size:13px;font-weight:700;color:#FFFFFF;">Open interactive dashboard &rarr;</a>
            </td>
          </tr>
        </table>
      </td>
    </tr>

    <!-- FOOTER -->
    <tr>
      <td class="px" style="padding:28px 36px 30px;">
        <table width="100%" cellpadding="0" cellspacing="0"><tr><td style="border-top:1px solid #EDEDEB;font-size:0;line-height:0;padding-bottom:18px;">&nbsp;</td></tr></table>
        <p style="margin:0;font-family:Arial,sans-serif;font-size:11px;color:#9CA0B3;line-height:1.6;">
          Report generated from Google Analytics 4 for the period above.<br>
          <?= h($brandName) ?> &nbsp;&middot;&nbsp; <?= h($footerNote) ?> &nbsp;&middot;&nbsp; <a href="#" style="color:#9CA0B3;">Manage email preferences</a> &nbsp;&middot;&nbsp; <a href="#" style="color:#9CA0B3;">Unsubscribe</a>
        </p>
      </td>
    </tr>

  </table>

</td></tr>
</table>
</body>
</html>
    <?php
    return ob_get_clean();
}
