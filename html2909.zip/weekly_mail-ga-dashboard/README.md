# GA4 Dashboard → Email Report

Turns your GA4 dashboard template into an automated email: pulls live
data straight from the Google Analytics Data API (reusing your existing
report logic) and sends it as a styled HTML email over SMTP — no
intermediate HTTP call to your own API endpoint needed.

## Files

| File | Purpose |
|---|---|
| `ga4-report-lib.php` | Your original GA4 API logic, refactored into `ga4_build_report()` — returns the `$report` array directly instead of echoing JSON. |
| `email-template.php` | Renders your dashboard HTML as an email, driven entirely by the `$report` array (no hardcoded numbers). |
| `send-report-email.php` | The script you actually run/cron: fetches data → renders HTML → sends via SMTP with PHPMailer. |
| `config.example.php` | Template for your credentials/settings. Copy to `config.php`. |
| `composer.json` | The two dependencies you need. |

Your original `GA4-dashboard-api.php` (the JSON endpoint your interactive
dashboard calls) doesn't need to change at all — keep it running as-is.
This is a separate, second consumer of the same GA4 data.

## 1. Install dependencies

```bash
cd /path/to/ga4-email-report
composer require google/analytics-data phpmailer/phpmailer
```

(If you already have `vendor/` set up for the existing dashboard API,
just run `composer require phpmailer/phpmailer` there and copy these
files in alongside it.)

## 2. GA4 credentials

Same service-account JSON you're already using
(`credentials-ga.json`) — copy it into this folder, or point
`ga.credentials_path` in `config.php` at wherever it already lives.

## 3. Configure

```bash
cp config.example.php config.php
```

Edit `config.php`:

- `ga.property_id` — your GA4 property ID (e.g. `524099388` for Trivium).
- `report_window` — defaults to `14daysAgo` → `yesterday` (fortnightly,
  ending yesterday since GA4's same-day data is often incomplete).
- `smtp` — see below.
- `recipients` — who gets the email.
- `report.logo_path` — optional, path to a PNG/JPG logo. Leave the
  default and just drop a `logo.png` in this folder, or set it to `''`
  to omit the logo block entirely.

**`config.php` contains secrets — do not commit it to git.** Add it to
`.gitignore` alongside `credentials-ga.json`.

## 4. SMTP setup

Fill in `config.php`'s `smtp` block:

```php
'smtp' => [
    'host'       => 'smtp.gmail.com',
    'port'       => 587,
    'encryption' => 'tls',
    'username'   => 'you@example.com',
    'password'   => 'your-app-password',
    'from_email' => 'analytics@example.com',
    'from_name'  => 'Trivium CTE Analytics',
],
```

Common providers:

| Provider | Host | Port | Encryption |
|---|---|---|---|
| Gmail / Google Workspace | `smtp.gmail.com` | 587 | `tls` |
| Microsoft 365 / Outlook | `smtp.office365.com` | 587 | `tls` |
| Amazon SES | `email-smtp.<region>.amazonaws.com` | 587 | `tls` |
| SendGrid | `smtp.sendgrid.net` | 587 | `tls` |
| Zoho Mail | `smtp.zoho.com` | 587 | `tls` |

**Gmail / Google Workspace note:** you can't use your normal account
password over SMTP. Generate an **App Password** at
`myaccount.google.com/apppasswords` (requires 2-Step Verification to be
on) and use that as `smtp.password`. If the "App Passwords" option is
missing, your Workspace admin has likely disabled it — ask them, or use
a transactional provider like SES/SendGrid instead, which tends to be
more reliable for automated sends anyway.

## 5. Test it

```bash
php send-report-email.php
```

You should see `Report email sent successfully to ...`. Check the
recipient inbox (and spam folder the first time).

Override the date range for a one-off test without touching
`config.php`:

```bash
php send-report-email.php --start=2026-06-22 --end=2026-07-05
```

If something fails, the script prints the error to STDERR and — if
`alert_email` is set in `config.php` — also emails a short plain-text
failure notice, so a broken cron job doesn't fail silently.

## 6. Schedule it (cron)

For a straightforward **weekly** send, add this to `crontab -e`:

```
0 8 * * 1 /usr/bin/php /path/to/send-report-email.php >> /path/to/ga4-email.log 2>&1
```

For **every other Monday** (true fortnightly), cron has no native
"every 2 weeks" — the simplest reliable approach is an ISO-week check
inside the same cron line:

```
0 8 * * 1 [ $(( $(date +\%V) \% 2 )) -eq 0 ] && /usr/bin/php /path/to/send-report-email.php >> /path/to/ga4-email.log 2>&1
```

That runs every Monday but only actually sends on even ISO week
numbers. Flip `-eq 0` to `-eq 1` if it lands on the wrong week the
first time and you want to shift it by a week.

## Notes / things you may want to extend later

- **KPI "Change" column:** the change % in the header table (▲/▼) is
  wired up in the template but the underlying GA4 fetch doesn't
  currently query a comparison period, so it will show as "—" for
  every metric. To populate it for real, call `ga4_build_report()` a
  second time for the prior period of equal length and pass the % diff
  in as each KPI's `delta`. Happy to wire that up if you want it.
- **Top Clicks URLs/pages:** same limitation your original file already
  noted — GA4's default reports don't expose per-click destination URLs
  unless you also request event parameters like `link_url` and
  `page_location`. The email currently just shows the event counts.
- **Page views list:** capped at 40 rows in the email (with a "+N more"
  note) so the message doesn't become enormous — full detail stays on
  your interactive dashboard.
