<?php

namespace App\Logging;

use PDO;

final class ReportLogRepository
{
    public function __construct(private PDO $pdo) {}

    public function alreadySent(
        string $type,
        string $startDate,
        string $endDate
    ): bool {
        $stmt = $this->pdo->prepare(
            'SELECT id
             FROM weekly_report_email_logs
             WHERE report_type = ?
               AND report_period_start = ?
               AND report_period_end = ?
               AND status = "sent"
             LIMIT 1'
        );

        $stmt->execute([$type, $startDate, $endDate]);

        return (bool) $stmt->fetchColumn();
    }

    public function createPending(
        string $type,
        string $startDate,
        string $endDate,
        string $recipients
    ): int {
        $stmt = $this->pdo->prepare(
            'INSERT INTO weekly_report_email_logs
             (report_type, report_period_start, report_period_end, recipients, status)
             VALUES (?, ?, ?, ?, "pending")
             ON DUPLICATE KEY UPDATE
                recipients = VALUES(recipients),
                status = "pending",
                error_message = NULL'
        );

        $stmt->execute([
            $type,
            $startDate,
            $endDate,
            $recipients
        ]);

        return (int) $this->pdo->lastInsertId();
    }

    public function markSent(
        string $type,
        string $startDate,
        string $endDate
    ): void {
        $stmt = $this->pdo->prepare(
            'UPDATE weekly_report_email_logs
             SET status = "sent",
                 sent_at = NOW(),
                 error_message = NULL
             WHERE report_type = ?
               AND report_period_start = ?
               AND report_period_end = ?'
        );

        $stmt->execute([$type, $startDate, $endDate]);
    }

    public function markFailed(
        string $type,
        string $startDate,
        string $endDate,
        string $error
    ): void {
        $stmt = $this->pdo->prepare(
            'UPDATE weekly_report_email_logs
             SET status = "failed",
                 error_message = ?
             WHERE report_type = ?
               AND report_period_start = ?
               AND report_period_end = ?'
        );

        $stmt->execute([
            substr($error, 0, 65000),
            $type,
            $startDate,
            $endDate
        ]);
    }
}
