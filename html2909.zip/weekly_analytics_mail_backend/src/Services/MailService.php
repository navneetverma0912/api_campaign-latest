<?php

namespace App\Services;

use App\Config\Env;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\PHPMailer;

final class MailService
{
    public function send(
        array $recipients,
        string $subject,
        string $htmlBody,
        array $attachments = []
    ): void {
        $mail = new PHPMailer(true);

        try {
            $mail->isSMTP();
            $mail->Host = Env::required('MAIL_HOST');
            $mail->SMTPAuth = true;
            $mail->Username = Env::required('MAIL_USERNAME');
            $mail->Password = Env::required('MAIL_PASSWORD');
            $mail->Port = (int) Env::get('MAIL_PORT', '587');

            $encryption = strtolower(Env::get('MAIL_ENCRYPTION', 'tls'));

            if ($encryption === 'ssl' || $encryption === 'smtps') {
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            } else {
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            }

            $mail->setFrom(
                Env::required('MAIL_FROM_EMAIL'),
                Env::get('MAIL_FROM_NAME', 'Weekly Analytics Reports')
            );

            foreach ($recipients as $recipient) {
                if (is_array($recipient)) {
                    $mail->addAddress(
                        $recipient['email'],
                        $recipient['name'] ?? ''
                    );
                } else {
                    $mail->addAddress($recipient);
                }
            }

            $mail->isHTML(true);
            $mail->CharSet = 'UTF-8';
            $mail->Subject = $subject;
            $mail->Body = $htmlBody;
            $mail->AltBody = trim(strip_tags($htmlBody));

            foreach ($attachments as $attachment) {
                if (!empty($attachment['path']) && is_file($attachment['path'])) {
                    $mail->addAttachment(
                        $attachment['path'],
                        $attachment['name'] ?? basename($attachment['path'])
                    );
                }
            }

            $mail->send();
        } catch (Exception $e) {
            throw new \RuntimeException(
                'Email sending failed: ' . $mail->ErrorInfo,
                0,
                $e
            );
        }
    }
}
