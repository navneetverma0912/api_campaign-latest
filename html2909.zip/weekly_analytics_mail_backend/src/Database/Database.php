<?php

namespace App\Database;

use App\Config\Env;
use PDO;

final class Database
{
    public static function connection(): PDO
    {
        $host = Env::required('DB_HOST');
        $port = Env::get('DB_PORT', '3306');
        $name = Env::required('DB_NAME');
        $user = Env::required('DB_USER');
        $password = Env::get('DB_PASSWORD', '');

        $dsn = "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4";

        return new PDO(
            $dsn,
            $user,
            $password,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ]
        );
    }
}
