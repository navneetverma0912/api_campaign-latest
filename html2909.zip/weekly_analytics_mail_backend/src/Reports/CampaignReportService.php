<?php

namespace App\Reports;

final class CampaignReportService
{
    /**
     * Replace this method with your existing Campaign DB/API query.
     */
    public function getReport(string $startDate, string $endDate): array
    {
        // Demo values. Replace with real Campaign analytics.
        $sent = 180;
        $opened = 121;
        $clicked = 12;
        $optouts = 1;

        return [
            'sent' => $sent,
            'opened' => $opened,
            'clicked' => $clicked,
            'optouts' => $optouts,
            'open_rate' => $this->rate($opened, $sent),
            'click_rate' => $this->rate($clicked, $sent),
            'optout_rate' => $this->rate($optouts, $sent),
        ];
    }

    private function rate(int $value, int $total): float
    {
        return $total > 0 ? ($value / $total) * 100 : 0;
    }
}
