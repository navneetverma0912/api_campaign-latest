<?php

namespace App\Reports;

final class WeeklyReportService
{
    public function __construct(
        private CampaignReportService $campaign,
        private GA4ReportService $ga4,
        private LinkedInReportService $linkedin,
        private WeeklyReportBuilder $builder
    ) {}

    public function generate(string $startDate, string $endDate): array
    {
        $campaign = $this->campaign->getReport($startDate, $endDate);
        $ga4 = $this->ga4->getReport($startDate, $endDate);
        $linkedin = $this->linkedin->getReport($startDate, $endDate);

        $html = $this->builder->build(
            $startDate,
            $endDate,
            $campaign,
            $ga4,
            $linkedin
        );

        return [
            'subject' => sprintf(
                'Weekly Analytics Report - %s to %s',
                date('d M Y', strtotime($startDate)),
                date('d M Y', strtotime($endDate))
            ),
            'html' => $html,
            'campaign' => $campaign,
            'ga4' => $ga4,
            'linkedin' => $linkedin,
        ];
    }
}
