<?php

namespace App\Reports;

final class WeeklyReportBuilder
{
    public function build(
        string $startDate,
        string $endDate,
        array $campaign,
        array $ga4,
        array $linkedin
    ): string {
        $period = htmlspecialchars(
            date('d M Y', strtotime($startDate)) . ' - ' .
            date('d M Y', strtotime($endDate)),
            ENT_QUOTES,
            'UTF-8'
        );

        $campaignRows = $this->rows([
            'Total Sent' => $campaign['sent'],
            'Total Opened' => $campaign['opened'],
            'Total Clicked' => $campaign['clicked'],
            'Opt-outs' => $campaign['optouts'],
            'Open Rate' => number_format($campaign['open_rate'], 1) . '%',
            'Click Rate' => number_format($campaign['click_rate'], 1) . '%',
            'Opt-out Rate' => number_format($campaign['optout_rate'], 1) . '%',
        ]);

        $ga4Rows = $this->rows([
            'Users' => $ga4['users'],
            'Sessions' => $ga4['sessions'],
            'Page Views' => $ga4['page_views'],
            'Engagement Rate' => number_format($ga4['engagement_rate'], 1) . '%',
        ]);

        $linkedinRows = $this->rows([
            'Impressions' => $linkedin['impressions'],
            'Clicks' => $linkedin['clicks'],
            'Engagements' => $linkedin['engagements'],
            'Engagement Rate' => number_format($linkedin['engagement_rate'], 1) . '%',
        ]);

        return <<<HTML
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Weekly Analytics Report</title>
</head>
<body style="margin:0;padding:0;background:#f4f6f8;font-family:Arial,sans-serif;color:#222;">
<div style="max-width:800px;margin:0 auto;background:#fff;padding:30px;">

<h1 style="margin-top:0;">Weekly Analytics Report</h1>

<p>
<strong>Reporting Period:</strong> {$period}
</p>

<p>
Please find below the weekly Campaign, Web Analytics and LinkedIn Analytics summary.
</p>

{$this->section('Campaign Analytics', $campaignRows)}
{$this->section('Web Analytics (GA4)', $ga4Rows)}
{$this->section('LinkedIn Analytics', $linkedinRows)}

<p style="margin-top:30px;color:#777;font-size:12px;">
This email was generated automatically by the weekly analytics reporting system.
</p>

</div>
</body>
</html>
HTML;
    }

    private function section(string $title, string $rows): string
    {
        $safeTitle = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');

        return <<<HTML
<div style="margin-top:25px;">
<h2 style="font-size:18px;">{$safeTitle}</h2>
<table style="width:100%;border-collapse:collapse;">
<thead>
<tr>
<th style="border:1px solid #ddd;padding:9px;text-align:left;background:#f5f5f5;">Metric</th>
<th style="border:1px solid #ddd;padding:9px;text-align:left;background:#f5f5f5;">Value</th>
</tr>
</thead>
<tbody>
{$rows}
</tbody>
</table>
</div>
HTML;
    }

    private function rows(array $data): string
    {
        $html = '';

        foreach ($data as $label => $value) {
            $label = htmlspecialchars((string) $label, ENT_QUOTES, 'UTF-8');
            $value = htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');

            $html .= <<<HTML
<tr>
<td style="border:1px solid #ddd;padding:9px;">{$label}</td>
<td style="border:1px solid #ddd;padding:9px;">{$value}</td>
</tr>
HTML;
        }

        return $html;
    }
}
