<?php

namespace App\Reports;

use App\Config\Env;

final class LinkedInReportService
{
    /**
     * Replace this method with your LinkedIn Community Management API calls.
     *
     * Credentials are intentionally not hard-coded here.
     */
    public function getReport(string $startDate, string $endDate): array
    {
        return [
            'impressions' => 5420,
            'clicks' => 320,
            'engagements' => 510,
            'engagement_rate' => 0,
            'configured' => (bool) Env::get('LINKEDIN_ACCESS_TOKEN'),
        ];
    }
}
