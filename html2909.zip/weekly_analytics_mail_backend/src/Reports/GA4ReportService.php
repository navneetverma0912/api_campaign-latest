<?php

namespace App\Reports;

use App\Config\Env;

final class GA4ReportService
{
    /**
     * Replace this method with your existing GA4 API implementation.
     *
     * GA4 credentials are intentionally not hard-coded here.
     */
    public function getReport(string $startDate, string $endDate): array
    {
        return [
            'users' => 1250,
            'sessions' => 1850,
            'page_views' => 4320,
            'engagement_rate' => 0,
            'configured' => (bool) Env::get('GA4_PROPERTY_ID'),
        ];
    }
}
