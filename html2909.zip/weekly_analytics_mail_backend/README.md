# Weekly Analytics Mail Backend

PHP backend for sending Campaign, Web Analytics (GA4), and LinkedIn Analytics reports by email through a weekly cron job.

## 1. Requirements

- PHP 8.1+
- Composer
- MySQL/MariaDB (only required if you enable send logging)
- SMTP credentials
- Linux/Hostinger/EC2 server for cron

## 2. Install

```bash
composer install
cp .env.example .env
```

Edit `.env` with the real SMTP and database values.

For Gmail/Google Workspace, use an approved SMTP credential/app password or your organization's approved authentication method. Do not commit `.env`.

## 3. Test manually

```bash
php cron/weekly_reports.php
```

A successful run prints the report period and recipient count.

## 4. Weekly cron

Example: every Monday at 9:00 AM:

```cron
0 9 * * 1 /usr/bin/php /home/USERNAME/weekly_analytics_mail/cron/weekly_reports.php >> /home/USERNAME/weekly_analytics_mail/logs/weekly_reports.log 2>&1
```

## 5. Database

Run:

```bash
mysql -u root -p analytics < database/schema.sql
```

The logging table prevents the same report period from being sent twice.

## 6. Connecting your real analytics APIs

Replace the demo implementations in:

- `src/Reports/CampaignReportService.php`
- `src/Reports/GA4ReportService.php`
- `src/Reports/LinkedInReportService.php`

Each service returns a normalized array consumed by the email template.

The mail/cron/logging code does not need to change when those API implementations change.
