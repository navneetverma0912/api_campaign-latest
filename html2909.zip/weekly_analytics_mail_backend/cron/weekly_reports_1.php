<?php

declare(strict_types=1);

require_once __DIR__ . '/../vendor/autoload.php';

use App\Config\Env;
use App\Database\Database;
use App\Logging\ReportLogRepository;
use App\Reports\CampaignReportService;
use App\Reports\GA4ReportService;
use App\Reports\LinkedInReportService;
use App\Reports\WeeklyReportBuilder;
use App\Reports\WeeklyReportService;
use App\Services\MailService;

try {
    // Load environment
    Env::load(__DIR__ . '/../.env');

    date_default_timezone_set('Asia/Kolkata');

    // Last 7 completed days
    $endDate = date('Y-m-d', strtotime('yesterday'));
    $startDate = date('Y-m-d', strtotime($endDate . ' -6 days'));

    $reportType = 'weekly_analytics';

    $recipients = array_filter(
        array_map(
            'trim',
            explode(',', Env::get('REPORT_RECIPIENTS', ''))
        )
    );

    if (empty($recipients)) {
        throw new RuntimeException(
            'REPORT_RECIPIENTS is not configured in .env'
        );
    }

    echo "Weekly Analytics Report\n";
    echo "Period: {$startDate} to {$endDate}\n";

    // Database
    // $database = new Database();
    // $pdo = $database->getConnection();
    $pdo = Database::connection();

    // Prevent duplicate weekly email
    $logRepository = new ReportLogRepository($pdo);

    if (
        $logRepository->alreadySent(
            $reportType,
            $startDate,
            $endDate
        )
    ) {
        echo "Report already sent for this period.\n";
        exit(0);
    }

    // Create pending log
    $logId = $logRepository->createPending(
        $reportType,
        $startDate,
        $endDate,
        implode(',', $recipients)
    );

    try {
        // Reports
        $campaignService = new CampaignReportService();
        $ga4Service = new GA4ReportService();
        $linkedinService = new LinkedInReportService();

        $campaignData = $campaignService->getReport(
            $startDate,
            $endDate
        );

        $ga4Data = $ga4Service->getReport(
            $startDate,
            $endDate
        );

        $linkedinData = $linkedinService->getReport(
            $startDate,
            $endDate
        );

        // Build email
        $builder = new WeeklyReportBuilder();

        $html = $builder->build(
            $startDate,
            $endDate,
            $campaignData,
            $ga4Data,
            $linkedinData
        );

        // Send email
        $mailService = new MailService();

        $mailService->send(
            $recipients,
            'Weekly Analytics Report - ' . $startDate . ' to ' . $endDate,
            $html
        );

        // Mark successful
        $logRepository->markSent($logId);

        echo "Weekly report sent successfully.\n";

        exit(0);

    } catch (Throwable $e) {

        $logRepository->markFailed(
            $logId,
            $e->getMessage()
        );

        throw $e;
    }

} catch (Throwable $e) {

    echo "ERROR: " . $e->getMessage() . PHP_EOL;

    exit(1);
}
