<?php

session_start();

$clientId = "77p6scab0e42ns";
$clientSecret = "WPL_AP1.ueYovQTF7hcPfUxy.WJy14A==";

$redirectUri = "https://triviumedu.com/api-campaign/callback.php";


/*
|--------------------------------------------------------------------------
| Check authorization code
|--------------------------------------------------------------------------
*/

if (!isset($_GET['code'])) {
    die("Authorization code not found.");
}

$code = $_GET['code'];


/*
|--------------------------------------------------------------------------
| Check PKCE verifier
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['linkedin_code_verifier'])) {
    die("PKCE code verifier not found in session.");
}

$codeVerifier = $_SESSION['linkedin_code_verifier'];


/*
|--------------------------------------------------------------------------
| Exchange authorization code for access token
|--------------------------------------------------------------------------
*/

$postData = [
    'grant_type' => 'authorization_code',
    'code' => $code,
    'client_id' => $clientId,
    'client_secret' => $clientSecret,
    'redirect_uri' => $redirectUri,
    'code_verifier' => $codeVerifier
];


$ch = curl_init(
    "https://www.linkedin.com/oauth/v2/accessToken"
);

curl_setopt_array($ch, [
    CURLOPT_POST => true,

    CURLOPT_POSTFIELDS =>
        http_build_query($postData),

    CURLOPT_RETURNTRANSFER => true,

    CURLOPT_HTTPHEADER => [
        "Content-Type: application/x-www-form-urlencoded"
    ]
]);


$response = curl_exec($ch);

$httpCode = curl_getinfo(
    $ch,
    CURLINFO_HTTP_CODE
);

$curlError = curl_error($ch);

curl_close($ch);


/*
|--------------------------------------------------------------------------
| cURL error
|--------------------------------------------------------------------------
*/

if ($curlError) {
    die("cURL Error: " . $curlError);
}


$data = json_decode($response, true);


/*
|--------------------------------------------------------------------------
| Access token generated
|--------------------------------------------------------------------------
*/
$expiresIn   = $_POST['expires_in'] ?? null;

// if (empty($accessToken)) {
//     die("Access token is required.");
// }

$expiresAt = null;

if (!empty($expiresIn)) {
    $expiresAt = date(
        'Y-m-d H:i:s',
        time() + (int)$expiresIn
    );
}
if (isset($data['access_token'])) {

    $accessToken = $data['access_token'];

    $_SESSION['linkedin_access_token'] =
        $accessToken;


    // Optional: save expiry
    $_SESSION['linkedin_expires_in'] =  $data['expires_in'] ?? null;
    // Check if token already exists
    $stmt = $pdo->query("SELECT id FROM linkedin_tokens LIMIT 1");
    $existing = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($existing) {

        $stmt = $pdo->prepare("
            UPDATE linkedin_tokens
            SET access_token = ?,
                expires_at = ?
            WHERE id = ?
        ");
    
        $stmt->execute([
            $accessToken,
            $expiresAt,
            $existing['id']
        ]);
    
    } else {
    
        $stmt = $pdo->prepare("
            INSERT INTO linkedin_tokens
            (access_token, expires_at)
            VALUES (?, ?)
        ");
    
        $stmt->execute([
            $accessToken,
            $expiresAt
        ]);
    }
    /*
    |--------------------------------------------------------------------------
    | Redirect after successful authentication
    |--------------------------------------------------------------------------
    */

    header("Location: linkedin_cre.php");
    exit;
}


/*
|--------------------------------------------------------------------------
| Error debugging
|--------------------------------------------------------------------------
*/

echo "<h3>LinkedIn OAuth Error</h3>";

echo "<pre>";

print_r($data);

echo "</pre>";

echo "<h3>HTTP Status</h3>";

echo $httpCode;

?>