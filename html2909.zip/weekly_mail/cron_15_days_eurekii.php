<?php
// cron_send_campaign_mails.php

define('CAMPAIGN_REPORT_INCLUDE_ONLY', true); // prevent the CLI block from running

require_once '../db.php';              // your PDO $pdo connection
require_once 'send-campaign-reports-eurekii.php';  // now safe to include — only defines functions

if (!is_file(__DIR__ . '/config-eurekii.php')) {
    fwrite(STDERR, "Missing config-eurekii.php\n");
    exit(1);
}
$config = require __DIR__ . '/config-eurekii.php';
// print_r($config);die;
try {
    $today = date('Y-m-d');

    $stmt = $pdo->prepare("
        SELECT
            c.id,
            c.name,
            c.start_date,
            c.end_date,
            c.c_campaign_owner,
            GROUP_CONCAT(DISTINCT me.from_address) AS from_addresses
        FROM campaign c
        LEFT JOIN mass_email me ON me.campaign_id = c.id
        WHERE c.start_date <= :today
          AND (c.end_date >= :today OR c.end_date IS NULL)
          AND c.c_campaign_owner != 'Test'
          AND c.c_campaign_owner != 'Not Set'
        GROUP BY c.id
    ");
    $stmt->execute([':today' => $today]);

    $campaigns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    print_r($campaigns);//die;
    if (empty($campaigns)) {
        echo "No active campaigns for {$today}.\n";
        exit;
    }
    foreach ($campaigns as $campaign) {
        $recipients = [];
        if (!empty($campaign['from_addresses'])) {
            $recipients = array_values(array_unique(array_filter(array_map(
                'trim',
                explode(',', $campaign['from_addresses'])
            ))));
        }
        // Schedule check: start day, end day, or every 15 days in between
        $startStr = substr($campaign['start_date'], 0, 10);
        $endStr   = !empty($campaign['end_date']) ? substr($campaign['end_date'], 0, 10) : null;
    
        $daysSinceStart = (new DateTime($startStr))->diff(new DateTime($today))->days;
    
        $isStartDay    = ($daysSinceStart === 0);
        $isEndDay      = ($endStr !== null && $endStr === $today);
        $isIntervalDay = ($daysSinceStart > 0 && $daysSinceStart % 15 === 0);
        echo "Start Day- ". $startStr . $isStartDay ."\n";
        echo "End Day- ". $endStr . $isEndDay ."\n";
        echo "Interval Day- ". $daysSinceStart . $isIntervalDay ."\n";
        if (!($isStartDay || $isEndDay || $isIntervalDay)) {
            continue;
        }
        if (empty($recipients)) {
            echo "Skipping campaign {$campaign['id']} ({$campaign['name']}): no from_address on file.\n";
            continue;
        } 
        print_r('recipients:--' . $recipients);
        // TESTING: send to yourself. For production use $recipients instead.
        $sendTo = ['navneet.verma@algoqube.com'];
        // $sendTo = [$campaign['from_addresses']];
        // $sendTo = array_map(
        //     'trim',
        //     explode(',', $campaign['from_addresses'])
        // );
        
    
        try {
            $ok = sendCampaignReportById((string)$campaign['id'], $sendTo, $config);
            echo $ok
                ? "Mail sent for campaign_id: {$campaign['id']} -> " . implode(', ', $sendTo) . "\n"
                : "FAILED for campaign_id: {$campaign['id']}\n";
            // $ok = sendCampaignReportById((string)$campaign['id'], $sendTo, $config);
            // echo $ok
            //     ? "Mail sent for campaign_id: {$campaign['id']} -> " . implode(', ', $sendTo) . "\n"
            //     : "FAILED for campaign_id: {$campaign['id']}\n";
        } catch (Throwable $e) {
            error_log("Failed to send mail for campaign_id {$campaign['id']}: " . $e->getMessage());
        }
    }
} catch (PDOException $e) {
    error_log("DB error in cron_send_campaign_mails_eurekii.php: " . $e->getMessage());
}