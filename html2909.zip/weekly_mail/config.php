<?php
/**
 * Copy this file to config.php and fill in your real values.
 * config.php should NOT be committed to version control (it holds SMTP credentials).
 */

return [
    // Full URL to the campaign data API (the index.php you shared)
    'api_url' => 'https://triviumedu.com/api-campaign/campaign-dashboard-trivium.php',

    // ---- SMTP ----
    'smtp_host'   => 'smtp.hostinger.com',
    'smtp_port'   => 587,          // 587 for TLS, 465 for SSL
    'smtp_secure' => 'tls',        // 'tls' or 'ssl'
    'smtp_user'   => 'itadmin@navneet.org.in',
    'smtp_pass'   => 'N@vneet.@123aws',
    'from_email' => 'itadmin@navneet.org.in',
    'from_name'  => 'Trivium Campaign Reports',

    // ---- Recipients ----
    'recipients' => [
        'navneet.verma@algoqube.com'
    ],
    'bcc' => [
        // 'aditya.bhatia@triviumedu.com',
        // 'tim.connors@triviumedu.com',
        // 'richa.chugh@triviumedu.com',
        // 'harsh.virmani@triviumedu.com',
        // 'saurabh.rawat@triviumedu.com',
        // 'corinne.winston@triviumedu.com',
        // 'suraj.pandey@triviumedu.com',
        // 'archive@yourdomain.com',
    ],

    // ---- Cosmetics ----
    'report_prefix' => 'Campaign Analytics',
    'dashboard_url' => 'https://triviumedu.com/api-campaign/index.html',

    // Optional PNG/JPG logo shown in the email header. Leave the file missing
    // and the logo block is automatically removed from the email.
    'logo_path' => 'https://triviumedu.com/api-campaign/assets/trivium-logo.png'
];
