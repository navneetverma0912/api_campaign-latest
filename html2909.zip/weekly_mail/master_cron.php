<?php

/**
 * Master Cron
 *
 * Campaign:
 *   Runs every day
 *
 * Web:
 *   Runs only on 1st and 15th of every month
 */

date_default_timezone_set('Asia/Kolkata');

$today = date('Y-m-d');
$day   = (int) date('j');

echo "========================================\n";
echo "Master Cron Started: " . date('Y-m-d H:i:s') . "\n";
echo "========================================\n";


/*
|--------------------------------------------------------------------------
| CONFIG - PHP executable
|--------------------------------------------------------------------------
*/

$php = '/usr/local/bin/php';


/*
|--------------------------------------------------------------------------
| JOBS
|--------------------------------------------------------------------------
|
| Replace these paths with your actual cron PHP files.
|
*/

$campaignJobs = [
    '/home/jtrivium/public_html/api-campaign/weekly_mail/cron_15_days.php',
    '/home/jtrivium/public_html/api-campaign/weekly_mail/cron_15_days_eurekii.php',
    // '/home/jtrivium/public_html/api-campaign/weekly_mail/cron_send_campaign_mails.php',
    // '/home/jtrivium/public_html/api-campaign/weekly_mail/cron_send_campaign_mails_eurekii.php'
];

$webJobs = [
    '/home/jtrivium/public_html/api-campaign/weekly_mail/send-web-reports.php.php',
    '/home/jtrivium/public_html/api-campaign/weekly_mail/send-web-reports-eurekii.php',
    '/home/jtrivium/public_html/api-campaign/weekly_mail/send-web-reports-cte.php'
];


/*
|--------------------------------------------------------------------------
| LOG FUNCTION
|--------------------------------------------------------------------------
*/

function runJob($php, $job)
{
    echo "\n----------------------------------------\n";
    echo "Running: {$job}\n";
    echo "Started: " . date('Y-m-d H:i:s') . "\n";

    if (!file_exists($job)) {
        echo "ERROR: File does not exist\n";
        return false;
    }

    $command = $php . ' ' . escapeshellarg($job) . ' 2>&1';

    $output = [];
    $returnCode = 0;

    exec($command, $output, $returnCode);

    if (!empty($output)) {
        echo implode("\n", $output) . "\n";
    }

    if ($returnCode === 0) {
        echo "SUCCESS: {$job}\n";
        return true;
    }

    echo "FAILED: {$job}\n";
    echo "Return Code: {$returnCode}\n";

    return false;
}


/*
|--------------------------------------------------------------------------
| 1. CAMPAIGN JOBS
|--------------------------------------------------------------------------
|
| Campaign reports run DAILY.
|
*/

echo "\n========== CAMPAIGN JOBS ==========\n";

foreach ($campaignJobs as $job) {
    runJob($php, $job);
}


/*
|--------------------------------------------------------------------------
| 2. WEB JOBS
|--------------------------------------------------------------------------
|
| Web analytics run only on:
|
| 1st
| 15th
|
*/

if ($day === 1 || $day === 15) {

    echo "\n========== WEB JOBS ==========\n";
    echo "Today is {$day}th - running web analytics.\n";

    foreach ($webJobs as $job) {
        runJob($php, $job);
    }

} else {

    echo "\n========== WEB JOBS ==========\n";
    echo "Today is {$day}th - web jobs skipped.\n";
}


/*
|--------------------------------------------------------------------------
| FINISHED
|--------------------------------------------------------------------------
*/

echo "\n========================================\n";
echo "Master Cron Finished: " . date('Y-m-d H:i:s') . "\n";
echo "========================================\n";